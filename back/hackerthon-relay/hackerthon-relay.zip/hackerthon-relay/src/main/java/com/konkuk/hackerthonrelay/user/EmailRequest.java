package com.konkuk.hackerthonrelay.user;

import lombok.Getter;
import lombok.Setter;

@Setter @Getter
public class EmailRequest {
	private String email;

	public EmailRequest() {
	}

}
